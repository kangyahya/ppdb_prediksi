<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Skripsi Teknik Informatika</b> 
    </div>
    <strong>Copyright &copy; 2020 Universitas Catur Insan Cendekia Cirebon</a>.</strong>
</footer>