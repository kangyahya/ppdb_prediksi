<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Dashboard <?= $this->session->userdata('level') ?>
        </h1>
    </section>

    <!-- Main content -->
    <section class="content">


        <div class="row">
            <div class="col-xs-12">
                <div class="box box-primary">

                    <div class="box-body">
                        <h3 style="text-align:center; font-weight:bold; font-family:Segoe UI, sans-serif">SELAMAT DATANG DI</h3><br>
                        <h4 style=" text-align:center; font-weight:bold; font-family:'Segoe UI', sans-serif">APLIKASI PENILAIAN KEPUASAN LAYANAN MANAJEMEN </h4>
                        <h4 style=" text-align:center; font-weight:bold; font-family:'Segoe UI', sans-serif">SISTEM TATA PAMONG DAN TATA KELOLA </h4>
                        <h4 style=" text-align:center; font-weight:bold; font-family:'Segoe UI', sans-serif">OLEH KARYAWAN/ STAFF </h4>
                        <br><br>
                        <img style="display:block; margin-left:auto; margin-right:auto" src="<?php echo base_url(); ?>assets/login_admin/img/cic.png" width="290px">
                        <br>
                        <br>
                        <br>
                        <br>

                    </div>
                </div>


    </section>
</div>